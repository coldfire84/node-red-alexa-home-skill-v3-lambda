# Node-RED Smart Home Control
Please see full [README.md](https://github.com/coldfire84/node-red-alexa-home-skill-v3-web/blob/master/README.md) for the combined service.